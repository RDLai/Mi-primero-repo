# StockX Receip Generator
This is a discord bot that generates receipts for StockX, Nike, Apple and more. This is the perfect thing to make reselling more safe.

Join our discord to see what generators we got and what you can do. Trust me it is worth it.

https://discord.gg/confirm
